import UIKit


/*
 1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.

 2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).

 3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.

 4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.

 5. Создать несколько объектов каждого класса. Применить к ним различные действия.

 6. Вывести сами объекты в консоль.*/

enum Action {
    case sportCarAction
    case tunkCarAction
}
enum EngineState {
    case on, off
}
enum WindowState {
    case opened, closed
}

protocol Car: AnyObject {
    var hp: Int { get }
    var engineSt: EngineState { get set }
    var windowSt: WindowState { get set }
    func handle(action: Action)
}
    extension Car {
        func handleEnine (state: EngineState) {
            self.engineSt = state
        }
        func window (state: WindowState) {
            self.windowSt = state
        }
    }
class TunkCar: Car  {
    var hp: Int = 500
    var engineSt: EngineState = .off
    var windowSt: WindowState = .closed
    func handle(action: Action) {
        switch action {
        case .tunkCarAction:
            print ("Цистена")
        default:
            break
        }
    }
    init (hp: Int) {
    self.hp = hp
}
}
class SportCar: Car {
    var hp: Int = 200
    var engineSt: EngineState = .off
    var windowSt: WindowState = .opened
    func handle(action: Action) {
        switch action {
        case.sportCarAction :
            print ("Спортивная машина")
        default:
            break
        }
    }
    init (hp: Int ) {
    self.hp = hp
}
    
}
extension TunkCar: CustomStringConvertible {
    var description: String {
        return "это грузовик. Двигатель-\(EngineState.off), Окна-\(WindowState.closed), Мощность-\(hp)"
    }
}

extension SportCar: CustomStringConvertible {
    var description: String {
        return "это Спортивный автомобиль. Двигатель-\(EngineState.off), Окна-\(WindowState.closed), Мощность-\(hp)"
   }
}
var t = TunkCar (hp: 500)
let s = SportCar (hp: 250)

s.description
s.handleEnine(state: .on)
s.window(state: .opened)

print (s.description)
print (t.description)

